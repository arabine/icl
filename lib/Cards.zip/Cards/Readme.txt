AG Multimedia Design
http://www.agstudio.cjb.net
agemini2002@tiscali.it

        #
        
       ##   ###  ###  ###   ###
        #  #    #   # #  # #
        #  #    #   # #  #  ###
        #  #    #   # #  #     #
       ###  ###  ###  #  # ####

These icons are intended for private and non-commercial use only. Usage on other websites or in publications like magazienes or CD-ROMs is not allowed without my permission. They must not be redistribuited as altered versions or without this readme file. You may convert them to any other OS for yourself - but distribution without my written permission is prohibited.

If you want to support the develop of the future icons and other stuff by AG Multimedia Design, please visit www.agstudio.cjb.net and send me an email.